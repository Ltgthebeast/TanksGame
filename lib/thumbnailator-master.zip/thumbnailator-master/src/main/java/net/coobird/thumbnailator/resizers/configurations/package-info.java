/**
 * This package provides enums which are used to set rendering hints used when
 * using {@link net.coobird.thumbnailator.resizers.Resizers} to create
 * thumbnails.
 */
package net.coobird.thumbnailator.resizers.configurations;
