/**
 * This package provides classes which can be used to make thumbnails given
 * parameters to create the images.
 */
package net.coobird.thumbnailator.makers;
