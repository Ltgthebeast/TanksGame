/**
 * This package provides classes which provides convenient builders for classes
 * which are used by Thumbnailator.
 */
package net.coobird.thumbnailator.builders;
