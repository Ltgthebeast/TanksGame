/**
 * This package contains utilities classes used by Thumbnailator.
 */
package net.coobird.thumbnailator.util;
