/**
 * This package contains utilities classes used to handle Exif metadata.
 */
package net.coobird.thumbnailator.util.exif;
