/**
 * This package provides classes which perform image input and output
 * operations, which can be used to aid in creating and writing thumbnails
 * to and from external sources.
 */
package net.coobird.thumbnailator.tasks;
