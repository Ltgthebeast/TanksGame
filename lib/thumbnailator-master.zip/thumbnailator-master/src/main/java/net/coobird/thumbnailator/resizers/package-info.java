/**
 * This package provides classes which perform image resizing operations which
 * is used to create thumbnails with Thumbnailator.
 */
package net.coobird.thumbnailator.resizers;
